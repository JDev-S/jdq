<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*PRINCIPAL*/
Route::get('/', function () {
    return view('/principal/index');
});

/*ACERCA DE*/
Route::get('/acercade', function () {
    return view('/principal/acercade');
});

/*CONTACTO*/
Route::get('/contacto', function () {
    return view('/principal/contacto');
});


/*PRODUCTO*/
Route::get('/producto', function () {
    return view('/principal/producto');
});

/*CATALOGO*/
Route::get('/catalogo', function () {
    return view('/principal/productos');
});

