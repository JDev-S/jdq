
<?php $__env->startSection('contenido'); ?>
<section class="section-slide img-fluid">
    <div class="title text-center">
        <h3 class="heading-3 font-weight-bold">Nombre del producto</h3>
        
    </div>
</section>

<section class="section-toolbar">
    <div class="product-toolbar">
        <div class="my-container">
            <a href="/catalogo">Cátalogo</a> /
            <a href="/catalogo">Categoría</a> /
            <a href="javascript:void(0)">Nombre del producto</a> 
           
        </div>
    </div>
</section>

<section class="section-product-detail-v2 ">
    <div class="my-container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="product-detail-v2">
                    <div class="col-prod-2">
                        <div class="js-slide-product3 slick-scoll">
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-2.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-3.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-4.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-7.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>
                    </div>
                    <div class="col-prod-10">
                        <div class="js-product-thumbnail3 slick-scoll1">
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-2.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-3.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-4.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-7.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\P-Detail-v1-8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="row">
                    <div class="col-75">
                        <div class="info-product">
                            <div class="rating d-flex  align-items-center">
                                <div>Categoria</div>
                                <div>
                                    <span><i class="fa fa-star" style="color: rgba(34, 34, 34, 1.)"></i><i class="fa fa-star" style="color: rgba(34, 34, 34, 1.)"></i><i class="fa fa-star" style="color: rgba(34, 34, 34, 1.)"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color:  #aaa"></i>
                                    </span>
                                    
                                </div>
                            </div>
                            <h4 class="name-product font-weight-bold">Nombre del producto</h4>
                            <h4 class="price-product">$199</h4>
                            <p>Pequeña descripción.</p>
                        </div>
                        <div class="customer-option">
                            <div class="select-color">
                                <h4 class="heading-4 font-weighth-bold select-option-p2">Colores</h4>
                                <a href="javascript:void(0)"><img src="img\P-Detail-v3-4.jpg" alt="_img color" class="img-fluid w-100"><span class="overlay"></span></a>
                                <a href="javascript:void(0)"><img src="img\P-Detail-v3-5.jpg" alt="_img color" class="img-fluid w-100"><span class="overlay"></span></a>
                            </div>
                            

                        </div>
                        <div class="link-page">

                            <div class="share">
                                <label class="font-weight-bold mb-0">Compartir:</label>
                                <a href="javascript:void(0)"><i class="ti ti-facebook"></i></a>
                                <a href="javascript:void(0)"><i class="ti-twitter-alt"></i></a>
                                <a href="javascript:void(0)"><i class="ti-pinterest"></i></a>
                                <a href="javascript:void(0)"><i class="ti-youtube"></i></a>
                                <a href="javascript:void(0)"><i class="ti-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-25"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-description">
    <div class="my-container">
        <ul class="tabs  d-flex justify-content-between col-xl-6 col-md-8 col-md-8">
            <li class="tabs-link current font-weight-bold" data-tab="tab-2">Información adicional</li>
            
        </ul>

        <div id="tab-2"  class="tab-content current">
            <table class="table">
                <tbody>
                    <tr>
                        <td>Tmaño</td>
                        <td>chico, mediano, grande, extra grande</td>
                    </tr>
                    <tr>
                        <td>Color</td>
                        <td>negro, azul, gris, amarillo</td>
                    </tr>
                </tbody>
            </table>
        </div>

    </div>
</section>

<section class="section-product-v1">
    <div class="my-container">
        <h3 class="heading-3 text-center font-weight-bold text-capitalize">Productos relacionados</h3>
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>
                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Men's T-shirt</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(36)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>T-shirt Blade</h6>
                            </a>
                            <div class="dollar">$175<span>$150</span></div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Men's Orginals</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(50)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Vene Taupe</h6>
                            </a>
                            <div class="dollar">$120</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Classics</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                    <span>(150)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Mobius Bodycon</h6>
                            </a>
                            <div class="dollar">$140</div>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Lifestyle</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(20)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Maddie Plum</h6>
                            </a>
                            <div class="dollar">$80</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moda\moda\resources\views//principal/producto.blade.php ENDPATH**/ ?>