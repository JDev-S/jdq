
<?php $__env->startSection('contenido'); ?>
<section class="section-slide img-fluid">
    <div class="title text-center">
        <h3 class="heading-3 font-weight-bold">Catálogo</h3>

    </div>
</section>
<section class="section-category-spage">
    <div class="my-container">
        <div class="row align-items-center">
            <div class="col-xl-6 col-lg-6 col-sm-8 col-12 d-flex  align-items-center category">
                <div class="w-50 d-flex justify-content-between align-items-center" style="padding-right:15px;">
                    <h4 class="fs-30">Tipo de la categoría</h4>
                    <span class="lnr lnr-chevron-right"></span>
                </div>
                <div class="text">Mostrar 1-16 de 90 resultados</div>
            </div>
            <div class="col-xl-6 col-lg-6 col-sm-4  d-flex align-items-center justify-content-end">
                <div class="select-option-spage  d-flex align-items-center ">
                    <div class="filter-show d-flex">
                        <!--<div class="select-filter">
                            <select class="selected">
                                <option value="Filters">Filters </option>
                                <option>Featured</option>
                                <option>Best Selling</option>
                                <option>Alphabetically, A-Z</option>
                                <option>Alphabetically, Z-A</option>
                                <option>Price, low to high</option>
                                <option>Price, high to low</option>
                                <option>Date, new to old</option>
                                <option>Date, old to new</option>
                            </select>
                        </div>-->
                        <!--<div class="select-show">
                            <select>
                                <option value="Show 04">Show 04</option>
                                <option>12</option>
                                <option>24</option>
                                <option>48</option>
                            </select>
                        </div>-->
                    </div>
                    <!--<div class="list-gird">
                        <a href="javascript:void(0)" class="js-list"><i class="ti-layout-grid4-alt"></i></a>
                        <!--<a href="javascript:void(0)" class="js-grid"><i class="ti-menu-alt"></i></a>
                    </div>-->
                </div>
            </div>
        </div>
    </div>
</section>
<div class="js-sort-layout">
    <div class="section-product-v1">
        <div class="my-container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                            </div>
                            <div class="product-image">
                                <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                            </div>
                            <div class="product-image">
                                <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                            </div>
                            <div class="product-image">
                                <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                            </div>
                            <div class="product-image">
                                <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-slide-product slick-scoll">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Men's T-shirt</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(36)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>T-shirt Blade</h6>
                                </a>
                                <div class="dollar">$175<span>$150</span></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-slide-product slick-scoll">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Men's Orginals</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(50)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Vene Taupe</h6>
                                </a>
                                <div class="dollar">$120</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-slide-product slick-scoll">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Classics</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                        <span>(150)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Mobius Bodycon</h6>
                                </a>
                                <div class="dollar">$140</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12 ">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>
                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-layout-detail">
                                    <div class="js-slide-product slick-scoll">
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Izod T-Shirts</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(36)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Long Sleeve T-Shirts</h6>
                                </a>
                                <div class="dollar">$275<span>$150</span></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-slide-product slick-scoll">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Midi Dress</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                        <span>(100)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Aimee Terracotta</h6>
                                </a>
                                <div class="dollar">$115</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-slide-product slick-scoll">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Midi Dress</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(50)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Cowl Neck Satin</h6>
                                </a>
                                <div class="dollar">$140 <span>$290</span></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-slide-product slick-scoll">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Midi Dress</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(150)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Wine Maxi</h6>
                                </a>
                                <div class="dollar">$115</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2 ">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-slide-product slick-scoll">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Lifestyle</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(55)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Talkies Dresses</h6>
                                </a>
                                <div class="dollar">$100</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-layout-detail">
                                    <div class="js-slide-product slick-scoll">
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Lifestyle</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(20)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Maddie Plum</h6>
                                </a>
                                <div class="dollar">$80</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-layout-detail">
                                    <div class="js-slide-product slick-scoll">
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Man's T-shirt</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(20)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Chunky Knit</h6>
                                </a>
                                <div class="dollar">$109.99 </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-layout-detail">
                                    <div class="js-slide-product slick-scoll">
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Women's Originals</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                        <span>(150)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Cable Stitch </h6>
                                </a>
                                <div class="dollar">$180 <span>$150</span></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-layout-detail">
                                    <div class="js-slide-product slick-scoll">
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Woman's Originals</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(20)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Dremah Silk</h6>
                                </a>
                                <div class="dollar">$100</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-layout-detail">
                                    <div class="js-slide-product slick-scoll">
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Originals</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(36)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Little Black</h6>
                                </a>
                                <div class="dollar">$200</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-layout-detail">
                                    <div class="js-slide-product slick-scoll">
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Classics</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(36)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Blanca Suárez</h6>
                                </a>
                                <div class="dollar">$110</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-layout-detail">
                                    <div class="js-slide-product slick-scoll">
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes">
                                    <div>Men's T-shirts</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(36)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Skate T-Shirts</h6>
                                </a>
                                <div class="dollar">$150</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="product product-home2">
                        <div class="js-product-thumbnail img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>

                        <div class="title">
                            <div class="slick-destop">
                                <div class="js-layout-detail">
                                    <div class="js-slide-product slick-scoll">
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                        <div class="product-image">
                                            <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="information">
                                <div class="type-shoes  ">
                                    <div>Originals</div>
                                    <div>
                                        <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(25)</span>
                                    </div>
                                </div>
                                <a href="/producto">
                                    <h6>Wilfred Madine Blouse</h6>
                                </a>
                                <div class="dollar">$90<span>$120</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="js-sort my-container" style="margin-top: 45px">
    <div class="wrap margin-bot-30">
        <div class="product-list-sidebar">
            <div class="row">
                <div class="col-4__product-list-sidebar col-4__shop-page">
                    <div class="product1">
                        <div class="js-product-thumbnail2 img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>
                        <div class="slick-destop">
                            <div class="slick-child-destop">
                                <div class="js-slide-product2 slick-horizontal">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <div class="col-1__product-list-sidebar col-1__shop-page">
                    <div class="slick-destop">
                        <div class="slick-child-destop">
                            <div class="js-slide-product2 slick-scoll2">
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-7__product-list-sidebar col-7__shop-page">
                    <div class="title d-flex">
                        <div class="product-info">
                            <div class="rating-product d-flex align-items-center">
                                <div>Clothes Originals</div>
                                <div class="star">
                                    <span><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(36)</span>
                                </div>
                            </div>
                            <h5 class="name-product font-weight-bold">
                                T-shirt Blade
                            </h5>
                            <h5 class="price-product">
                                <span class="font-weight-bold">$175</span><del>$150</del>
                            </h5>
                            <div class="font-2 info">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </div>
                            <div class="icon ">
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-move"></span>
                                </a>
                                <a href="javascript:void(0)">
                                    Add to cart
                                </a>
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-heart"></span>
                                </a>
                            </div>
                            <div class="link-share">
                                <label class="font-weight-bold">Share:</label>
                                <a href="javascript:void(0)">
                                    <i class="ti-facebook"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-twitter-alt"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-pinterest"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-youtube"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-instagram"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wrap margin-bot-30">
        <div class="product-list-sidebar">
            <div class="row">
                <div class="col-4__product-list-sidebar col-4__shop-page">
                    <div class="product1">
                        <div class="js-product-thumbnail2 img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>
                        <div class="slick-destop">
                            <div class="slick-child-destop">
                                <div class="js-slide-product2 slick-horizontal">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1__product-list-sidebar col-1__shop-page">
                    <div class="slick-destop">
                        <div class="slick-child-destop">
                            <div class="js-slide-product2 slick-scoll2">
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-7__product-list-sidebar col-7__shop-page">
                    <div class="title d-flex">
                        <div class="product-info">
                            <div class="rating-product d-flex align-items-center">
                                <div>Clothes Originals</div>
                                <div class="star">
                                    <span><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(36)</span>
                                </div>
                            </div>
                            <h5 class="name-product font-weight-bold">
                                Aimee Terracotta
                            </h5>
                            <h5 class="price-product">
                                <span class="font-weight-bold">$175</span><del>$150</del>
                            </h5>
                            <div class="font-2 info">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </div>
                            <div class="icon ">
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-move"></span>
                                </a>
                                <a href="javascript:void(0)">
                                    Add to cart
                                </a>
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-heart"></span>
                                </a>
                            </div>
                            <div class="link-share">
                                <label class="font-weight-bold">Share:</label>
                                <a href="javascript:void(0)">
                                    <i class="ti-facebook"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-twitter-alt"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-pinterest"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-youtube"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-instagram"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wrap margin-bot-30">
        <div class="product-list-sidebar">
            <div class="row">
                <div class="col-4__product-list-sidebar col-4__shop-page">
                    <div class="product1">
                        <div class="js-product-thumbnail2 img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>
                        <div class="slick-destop">
                            <div class="slick-child-destop">
                                <div class="js-slide-product2 slick-horizontal">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="hot">Hot</div>
                    </div>
                </div>
                <div class="col-1__product-list-sidebar col-1__shop-page">
                    <div class="slick-destop">
                        <div class="slick-child-destop">
                            <div class="js-slide-product2 slick-scoll2">
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-7__product-list-sidebar col-7__shop-page">
                    <div class="title d-flex">
                        <div class="product-info">
                            <div class="rating-product d-flex align-items-center">
                                <div>Clothes Originals</div>
                                <div class="star">
                                    <span><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(36)</span>
                                </div>
                            </div>
                            <h5 class="name-product font-weight-bold">
                                Vene Taupe
                            </h5>
                            <h5 class="price-product">
                                <span class="font-weight-bold">$175</span><del>$150</del>
                            </h5>
                            <div class="font-2 info">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </div>
                            <div class="icon ">
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-move"></span>
                                </a>
                                <a href="javascript:void(0)">
                                    Add to cart
                                </a>
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-heart"></span>
                                </a>
                            </div>
                            <div class="link-share">
                                <label class="font-weight-bold">Share:</label>
                                <a href="javascript:void(0)">
                                    <i class="ti-facebook"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-twitter-alt"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-pinterest"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-youtube"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-instagram"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wrap margin-bot-30">
        <div class="product-list-sidebar">
            <div class="row">
                <div class="col-4__product-list-sidebar col-4__shop-page">
                    <div class="product1">
                        <div class="js-product-thumbnail2 img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>
                        <div class="slick-destop">
                            <div class="slick-child-destop">
                                <div class="js-slide-product2 slick-horizontal">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1__product-list-sidebar col-1__shop-page">
                    <div class="slick-destop">
                        <div class="slick-child-destop">
                            <div class="js-slide-product2 slick-scoll2">
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-7__product-list-sidebar col-7__shop-page">
                    <div class="title d-flex">
                        <div class="product-info">
                            <div class="rating-product d-flex align-items-center">
                                <div>Clothes Originals</div>
                                <div class="star">
                                    <span><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(36)</span>
                                </div>
                            </div>
                            <h5 class="name-product font-weight-bold">
                                Wine Maxi
                            </h5>
                            <h5 class="price-product">
                                <span class="font-weight-bold">$175</span><del>$150</del>
                            </h5>
                            <div class="font-2 info">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </div>
                            <div class="icon ">
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-move"></span>
                                </a>
                                <a href="javascript:void(0)">
                                    Add to cart
                                </a>
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-heart"></span>
                                </a>
                            </div>
                            <div class="link-share">
                                <label class="font-weight-bold">Share:</label>
                                <a href="javascript:void(0)">
                                    <i class="ti-facebook"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-twitter-alt"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-pinterest"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-youtube"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-instagram"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wrap margin-bot-30">
        <div class="product-list-sidebar">
            <div class="row">
                <div class="col-4__product-list-sidebar col-4__shop-page">
                    <div class="product1">
                        <div class="js-product-thumbnail2 img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>
                        <div class="slick-destop">
                            <div class="slick-child-destop">
                                <div class="js-slide-product2 slick-horizontal">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="sale">-50%</div>
                    </div>
                </div>
                <div class="col-1__product-list-sidebar col-1__shop-page">
                    <div class="slick-destop">
                        <div class="slick-child-destop">
                            <div class="js-slide-product2 slick-scoll2">
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-7__product-list-sidebar col-7__shop-page">
                    <div class="title d-flex">
                        <div class="product-info">
                            <div class="content">
                                <div class="rating-product d-flex align-items-center">
                                    <div>Clothes Originals</div>
                                    <div class="star">
                                        <span><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                        <span>(36)</span>
                                    </div>
                                </div>
                                <h5 class="name-product font-weight-bold">
                                    Wilfred Madine Blouse
                                </h5>
                                <h5 class="price-product">
                                    <span class="font-weight-bold">$175</span><del>$150</del>
                                </h5>
                                <div class="font-2 info">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </div>
                                <div class="icon ">
                                    <a href="javascript:void(0)">
                                        <span class="lnr lnr-move"></span>
                                    </a>
                                    <a href="javascript:void(0)">
                                        Add to cart
                                    </a>
                                    <a href="javascript:void(0)">
                                        <span class="lnr lnr-heart"></span>
                                    </a>
                                </div>
                                <div class="link-share">
                                    <label class="font-weight-bold">Share:</label>
                                    <a href="javascript:void(0)">
                                        <i class="ti-facebook"></i>
                                    </a>
                                    <a href="javascript:void(0)">
                                        <i class="ti-twitter-alt"></i>
                                    </a>
                                    <a href="javascript:void(0)">
                                        <i class="ti-pinterest"></i>
                                    </a>
                                    <a href="javascript:void(0)">
                                        <i class="ti-youtube"></i>
                                    </a>
                                    <a href="javascript:void(0)">
                                        <i class="ti-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wrap margin-bot-30">
        <div class="product-list-sidebar">
            <div class="row">
                <div class="col-4__product-list-sidebar col-4__shop-page">
                    <div class="product1">
                        <div class="js-product-thumbnail2 img-show">
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                            <div class="product-image">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </div>
                        </div>
                        <div class="slick-destop">
                            <div class="slick-child-destop">
                                <div class="js-slide-product2 slick-horizontal">
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                    <div class="product-image">
                                        <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-1__product-list-sidebar col-1__shop-page">
                    <div class="slick-destop">
                        <div class="slick-child-destop">
                            <div class="js-slide-product2 slick-scoll2">
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-7__product-list-sidebar col-7__shop-page">
                    <div class="title d-flex">
                        <div class="product-info">
                            <div class="rating-product d-flex align-items-center">
                                <div>Clothes Originals</div>
                                <div class="star">
                                    <span><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #222"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(36)</span>
                                </div>
                            </div>
                            <h5 class="name-product font-weight-bold">
                                Mobius Bodycon
                            </h5>
                            <h5 class="price-product">
                                <span class="font-weight-bold">$175</span><del>$150</del>
                            </h5>
                            <div class="font-2 info">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </div>
                            <div class="icon ">
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-move"></span>
                                </a>
                                <a href="javascript:void(0)">
                                    Add to cart
                                </a>
                                <a href="javascript:void(0)">
                                    <span class="lnr lnr-heart"></span>
                                </a>
                            </div>
                            <div class="link-share">
                                <label class="font-weight-bold">Share:</label>
                                <a href="javascript:void(0)">
                                    <i class="ti-facebook"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-twitter-alt"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-pinterest"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-youtube"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="ti-instagram"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section-next-page">
    <div class="my-container">
        <div class="content d-flex  justify-content-center">
            <div class="prev-arrow arrow">
                <a href="javascript:void(0)"><i class="lnr lnr-arrow-left"></i></a>
            </div>
            <div class="page d-flex align-items-center">
                <div class="select-page">
                    <select name="page" id="page">
                        <option value="page1">Pagina 1</option>
                        <option value="page2">Pagina 2</option>
                        <option value="page3">Pagina 3</option>
                        <option value="page4">Pagina 4</option>
                        <option value="page5">Pagina 5</option>
                        <option value="page6">Pagina 6</option>
                    </select>
                    <span><i class="fa fa-sort-down"></i></span>
                </div>
                de 6
            </div>
            <div class="next-arrow arrow">
                <a href="javascript:void(0)"><i class="lnr lnr-arrow-right"></i></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moda\moda\resources\views//principal/productos.blade.php ENDPATH**/ ?>