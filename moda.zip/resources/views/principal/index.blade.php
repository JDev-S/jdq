@extends('welcome')
@section('contenido')

<section class="section-slide-v1 section-slide-v2">
    <div class="js-slick-slide-v2 slick-header-v2">
        <div class="slider-child">
            <div class="img-slider">
                <img src="\img\page2_01.jpg" alt="_img-slider" class="img-fluid w-100">
            </div>
            <div class=" title">
                <div class="my-container">
                    <h1 class="mb-0">Título.</h1>
                    <p class="content font-weight-bold">Descripción</p>
                    <a href="/catalogo" class="btn-shop-now">Observar catalogo</a>
                </div>
            </div>
        </div>
        <div class="slider-child">
            <div class="img-slider">
                <img src="\img\page2_01-2.jpg" alt="_img-slider" class="img-fluid w-100">
            </div>
            <div class=" title">
                <div class="my-container">
                    <h1 class="mb-0">Título.</h1>
                    <p class="content font-weight-bold">Descripción</p>
                    <a href="/catalogo" class="btn-shop-now">Observar catalogo</a>
                </div>
            </div>
        </div>
        <div class="slider-child">
            <div class="img-slider">
                <img src="\img\page2_01-3.jpg" alt="_img-slider" class="img-fluid w-100">
            </div>
            <div class=" title">
                <div class="my-container">

                    <h1 class="mb-0">Título.</h1>
                    <p class="content font-weight-bold">Descripción</p>
                    <a href="/catalogo" class="btn-shop-now">Observar catalogo</a>
                </div>
            </div>
        </div>
    </div>

</section>



<section class="section-brand-home2">
    <div class="js-slick-brand-v2 my-container brand no-gutters">
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo1.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo2.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo3.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo4.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo5.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo1.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo2.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo3.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo4.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
        <div class="item">
            <a href="javascript:void(0)"><img src="\img\logo5.png" alt="_img-brand" class="img-fluid w-100"></a>
        </div>
    </div>
</section>






<section class="section-product-v1">
    <div class="my-container">
        <h3 class="heading-3 font-weight-bold text-center text-capitalize">Nuevos productos</h3>
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\20.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\20.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Men's T-shirt</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(36)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>T-shirt Blade</h6>
                            </a>
                            <div class="dollar">$175<span>$150</span></div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Men's Orginals</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(50)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Vene Taupe</h6>
                            </a>
                            <div class="dollar">$120</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Classics</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                    <span>(150)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Mobius Bodycon</h6>
                            </a>
                            <div class="dollar">$140</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Lifestyle</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(20)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Maddie Plum</h6>
                            </a>
                            <div class="dollar">$80</div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\14.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\14.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Midi Dresses</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                    <span>(100)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Aimee Terracotta</h6>
                            </a>
                            <div class="dollar">$115</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\15.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\15.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Midi Dresses</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(50)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Wilfred Madine Blouse</h6>
                            </a>
                            <div class="dollar">$140 <span>$290</span></div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\16.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\16.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Midi Dresses</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(150)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Wine Maxi</h6>
                            </a>
                            <div class="dollar">$115</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\17.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\17.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Midi T-shirt</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(20)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Chunky Knit</h6>
                            </a>
                            <div class="dollar">$109.99 </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>


<section class="section-banner-v1-page2">
    <div class="my-container">
        <div class="row no-gutters">
            <div class="col-xl-4 col-lg-4 col-md-4">
                <div class="banner01 relative image-effect">
                    <a href="grid-slidebar-left.html">
                        <img src="\img\page2_banner01.jpg" alt="_img banner" class="img-fluid w-100 ">
                    </a>
                    <div class="title absolute w-100 text-center">
                        <h3 class="m-0 heading-3 font-weight-bold">Título</h3>
                        <p class="para-fs30 m-0">Descripción</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 col-lg-8 col-md-8">
                <div class="row no-gutters">
                    <div class="col-12">
                        <div class="banner02 relative image-effect">
                            <a href="grid-slidebar-left.html">
                                <img src="\img\page2_banner02.jpg" alt="_img banner Homepage 2" class="img-fluid w-100">
                            </a>
                            <div class="title absolute">
                                <p class="para-fs30 m-0">
                                    Titulo
                                </p>
                                <h3 class="heading-3 text-capitalize font-weight-bold">Descripción</h3>

                                <a href="/catalogo" class="btn-shop-now">Ir al catálogo</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row no-gutters">
                    <div class="col-50" style="background: #f4f4f4; overflow: hidden;">
                        <div class="banner03 text-center relative ">
                            <div class="title absolute">
                                <h6 class="para-fs30 font-weight-bold">Daniel Quijano</h6>
                                <p class="para-fs18">Bienvenidos a la colección de daniel quijano.</p>
                                <a href="/catalogo" class="btn-shop-now">Ir al catálogo</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-50">
                        <div class="banner04 relative text-center image-effect">
                            <a href="grid-slidebar-left.html">
                                <img src="\img\page2_banner04.jpg" alt="_img banner Homepage v2" class="img-fluid w-100">
                            </a>
                            <div class="title absolute w-100">
                                <p class="para-fs30 m-0 text-capitalize">Título</p>
                                <h3 class="heading-3 font-weight-bold text-capitalize">Descripción</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--<section class="section-countdown-v2">
    <div class="my-container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 padding-bot-30 countdown-img">
                <div class="js-countdown-slick-show countdown-home2">
                    <div class="image">
                        <img src="\img\shoes-slick.png" alt="_img Homepagev2 Countdown" class="img-fluid w-100">
                    </div>
                    <div class="image">
                        <img src="\img\shoes-slick.png" alt="_img Homepagev2 Countdown" class="img-fluid w-100">
                    </div>
                    <div class="image">
                        <img src="\img\shoes-slick.png" alt="_img Homepagev2 Countdown" class="img-fluid w-100">
                    </div>
                </div>
                <div class="point-v21 js-popup-lookbook">
                    <a href="javascript:void(0)"><img src="\img\point_page2.png" alt="_img point Homepage2"></a>
                    <div class="content-popup popup-lookbook box">
                        <h6 class="text-center m-0">Welting</h6>
                        <p class="m-0">It is a long established fact that a reader will be distracted by the readable content.</p>
                    </div>
                </div>
                <div class="point-v22 js-popup-lookbook ">
                    <a href="javascript:void(0)"><img src="\img\point_page2.png" alt="_img point Homepage2"></a>
                    <div class="content-popup popup-lookbook box">
                        <h6 class="text-center m-0">Welting</h6>
                        <p class="m-0">It is a long established fact that a reader will be distracted by the readable content.</p>
                    </div>
                </div>
                <div class="point-v23 js-popup-lookbook">
                    <a href="javascript:void(0)"><img src="\img\point_page2.png" alt="_img point Homepage2"></a>
                    <div class="content-popup popup-lookbook box">
                        <h6 class="text-center m-0">Welting</h6>
                        <p class="m-0">It is a long established fact that a reader will be distracted by the readable content.</p>
                    </div>
                </div>
                <div class="point-v24 js-popup-lookbook">
                    <a href="javascript:void(0)"><img src="\img\point_page2.png" alt="_img point Homepage2"></a>
                    <div class="content-popup popup-lookbook box">
                        <h6 class="text-center m-0">Welting</h6>
                        <p class="m-0">It is a long established fact that a reader will be distracted by the readable content.</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 hot-deal">
                <h3 class="heading-3 font-weight-bold text-capitalize">Deal Of The Day </h3>
                <div class="js-countdown countdown">
                    <ul class="list-unstyled">
                        <li class="item">
                            <div>
                                <span id="days" class="number dots">
                                </span>
                                <b>:</b>
                            </div>
                            <p class="text">days</p>
                        </li>
                        <li class="item">
                            <div>
                                <span id="hours" class="number dots">
                                </span>
                                <b>:</b>
                            </div>
                            <p class="text">hours</p>
                        </li>
                        <li class="item">
                            <div>
                                <span id="minutes" class="number dots">
                                </span>
                                <b>:</b>
                            </div>

                            <p class="text">mins</p>
                        </li>
                        <li class="item">
                            <span id="seconds" class="number">
                            </span>
                            <p class="text">secs</p>
                        </li>
                    </ul>
                    <p id="EXPIRED"></p>
                </div>
                <h3 class="heading-3 font-weight-bold">Extreme Cashmere 2019</h3>
                <div class="dollar"><span class="heading-3 font-weight-bold">$200</span><del>$250</del></div>
                <div class="js-countdown-slick-title  countdown-slick-title">
                    <div class="countdown-title">
                        <img src="\img\page2_countdown2.png" alt="_img Homepagev2 Countdown" class="img-fluid w-100">
                    </div>
                    <div class="countdown-title">
                        <img src="\img\page2_countdown6.png" alt="_img Homepagev2 Countdown" class="img-fluid w-100">
                    </div>
                    <div class="countdown-title">
                        <img src="\img\page2_countdown4.png" alt="_img Homepagev2 Countdown" class="img-fluid w-100">
                    </div>
                    <div class="countdown-title">
                        <img src="\img\page2_countdown5.png" alt="_img Homepagev2 Countdown" class="img-fluid w-100">
                    </div>
                    <div class="countdown-title">
                        <img src="\img\page2_countdown3.png" alt="_img Homepagev2 Countdown" class="img-fluid w-100">
                    </div>
                </div>
                <a href="javascript:void(0)" class=" btn-shop-now">Shop Now</a>
            </div>
        </div>
    </div>
</section>-->

<section class="section-product-v1">
    <div class="my-container">
        <h3 class="heading-3 font-weight-bold text-center text-capitalize">Productos anteriores</h3>
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\20.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                        <div class="product-image">
                            <a href="/producto">
                                <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                            </a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\20.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Men's T-shirt</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(36)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>T-shirt Blade</h6>
                            </a>
                            <div class="dollar">$175<span>$150</span></div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Men's Orginals</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(50)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Vene Taupe</h6>
                            </a>
                            <div class="dollar">$120</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Classics</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                    <span>(150)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Mobius Bodycon</h6>
                            </a>
                            <div class="dollar">$140</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Lifestyle</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color: #aaa"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(20)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Maddie Plum</h6>
                            </a>
                            <div class="dollar">$80</div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\14.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\14.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Midi Dresses</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                    <span>(100)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Aimee Terracotta</h6>
                            </a>
                            <div class="dollar">$115</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\15.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\15.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Midi Dresses</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(50)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Wilfred Madine Blouse</h6>
                            </a>
                            <div class="dollar">$140 <span>$290</span></div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\16.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\16.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Midi Dresses</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(150)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Wine Maxi</h6>
                            </a>
                            <div class="dollar">$115</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
                <div class="product product-home2">
                    <div class="js-product-thumbnail img-show">
                        <div class="product-image">
                            <a href="/producto"><img src="\img\17.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\6.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\8.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\9.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                        <div class="product-image">
                            <a href="/producto"><img src="\img\5.jpg" alt="Product" class="img-fluid w-100"></a>

                        </div>
                    </div>

                    <div class="title">
                        <div class="slick-destop">
                            <div class="js-slide-product slick-scoll">
                                <div class="product-image">
                                    <img src="\img\17.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\6.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\8.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\9.jpg" alt="Product" class="img-fluid">
                                </div>
                                <div class="product-image">
                                    <img src="\img\5.jpg" alt="Product" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="information">
                            <div class="type-shoes">
                                <div>Midi T-shirt</div>
                                <div>
                                    <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star" style="color: #aaa;"></i></span>
                                    <span>(20)</span>
                                </div>
                            </div>
                            <a href="/producto">
                                <h6>Chunky Knit</h6>
                            </a>
                            <div class="dollar">$109.99 </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>




<section class="section-support-v1">
    <div class="my-container">
        <div class="row">
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                <div class="box">
                    <div class="icon"><i class="ti-truck"></i></div>
                    <div class="content">
                        <p class="m-0">Envios</p>
                        <span>Lo llevamos hasta tu casa</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                <div class="box">
                    <div class="icon"><i class="ti-gift"></i></div>
                    <div class="content">
                        <p class="m-0">Pequeños regalos</p>
                        <span>Pregunta por nuestros regalos</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 ">
                <div class="box">
                    <div class="icon"><i class="ti-headphone-alt"></i></div>
                    <div class="content">
                        <p class="m-0">Dudas</p>
                        <span>Llamanos a 464123456789</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                <div class="box">
                    <div class="icon"><i class="icon-ecommerce-sale"></i></div>
                    <div class="content">
                        <p class="m-0">Descuentos</p>
                        <span>Pregunta por nuestros descuentos</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-instagram-v1">
    <div class="my-container">
        <div class="row no-gutters">
            <div class="col-xl-3 col-lg-3 col-md-3">
                <div class="title">
                    <h3 class="heading-3 font-weight-bold text-capitalize">Siguenos en instagram</h3>
                    <a href="grid-slidebar-left.html">@engocreativetheme</a>
                </div>
            </div>
            <div class="col-xl-9 col-lg-9 col-md-9" style="margin-left: -2px;">
                <div class="row no-gutters">
                    <div class="col-xl-3 col-lg-3 col-md-3 relative img-insta">
                        <div class="img">
                            <img src="\img\page2_int1.jpg" alt="_img page2 instagram" class="img-fluid w-100 img-hover">
                        </div>
                        <div class="overlay absolute">
                        </div>
                        <a href="javascript:void(0)" class="icon-insta"><i class="ti-instagram"></i></a>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 relative img-insta">
                        <div class="img">
                            <img src="\img\page2_int2.jpg" alt="_img page2 instagram" class="img-fluid w-100 img-hover">
                        </div>
                        <div class="overlay absolute">
                        </div>
                        <a href="javascript:void(0)" class="icon-insta"><i class="ti-instagram"></i></a>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 relative img-insta">
                        <div class="img">
                            <img src="\img\page2_int3.jpg" alt="_img page2 instagram" class="img-fluid w-100 img-hover">
                        </div>
                        <div class="overlay absolute">
                        </div>
                        <a href="javascript:void(0)" class="icon-insta"><i class="ti-instagram"></i></a>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 relative img-insta">
                        <div class="img">
                            <img src="\img\page2_int4.jpg" alt="_img page2 instagram" class="img-fluid w-100 img-hover">
                        </div>
                        <div class="overlay absolute">
                        </div>
                        <a href="javascript:void(0)" class="icon-insta"><i class="ti-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@stop
